# La Saison des Braises

## Chapitre 10 — La dernière coulée

*POV Cael*

Je suis retourné au four la nuit précédant le départ.

Torve m'a ouvert sans poser de question. Il avait dû recevoir des ordres contraires ; il les a ignorés, comme il ignore les ordres depuis trente ans, ce qui est sa manière à lui d'être un homme.

La halle était éteinte. Un four éteint refroidit lentement : à minuit, les briques rendaient encore la chaleur du jour, et l'air sentait ce qu'il sent toujours ici, le sel chaud et le fer.

Je me suis assis contre la gueule du four deux.

Dix-neuf ans. Je connais chaque fissure de cette fonte. Je sais laquelle s'ouvre quand on monte trop vite et laquelle ne s'ouvrira jamais. Je sais à quelle heure la lumière entre par la verrière nord, et combien de coups il faut pour casser une cuve refroidie sans la fendre en travers.

Ce sont des choses inutiles. C'est tout ce que je possède.

Vaugrin tenait le four un. Il m'a appris en trois mois ce qu'un Braise doit savoir et en dix-neuf ans ce qu'un homme doit savoir, ce qui n'a rien à voir. Il disait : *on ne pousse jamais tout. Tu gardes toujours une braise pour toi. Le jour où tu pousses tout, tu ne trouves plus la porte.*

Il est mort à quarante-quatre ans, un dimanche, en s'asseyant sur le banc de la cour. Il avait poussé tout, tous les jours, pendant vingt-six ans, pour une maison qui l'a fait enterrer correctement et qui a embauché un remplaçant le mardi.

Le remplaçant, c'était moi.

J'ai posé la main sur la fonte tiède, une dernière fois, et je me suis autorisé une chose que je ne fais jamais : j'ai poussé un peu.

Pas pour fondre. Juste assez pour que le métal passe du tiède au chaud sous ma paume.

C'était bête. Ça ne servait à rien. Je crois que je voulais que quelque chose, dans cette halle, garde la trace de ma main pendant quelques heures après mon départ.

Torve est venu me chercher à la troisième cloche.

— Ils t'attendent.

— J'arrive.

— Dorne.

Il tenait quelque chose. Un morceau de toile roulé, noué.

— C'était à Vaugrin. Il m'a dit de le donner au suivant. J'ai jamais su si ça voulait dire le suivant après lui ou le suivant qui part. J'ai attendu dix-neuf ans, alors maintenant je choisis.

J'ai déroulé la toile dans la cour.

Un ciseau à froid, et une petite plaque de fer gravée à la main, de trois doigts de large. Dessus, quatre lignes maladroites : un mur, une porte en arche, deux tours inégales.

— Il disait que c'était chez lui, a dit Torve. Il disait que personne l'avait jamais dessiné.

J'ai regardé la plaque longtemps.

C'était la porte nord de Ghar.

Je l'ai reconnue parce que je suis passé dessous, à cinq ans, dans les bras de quelqu'un dont je ne me rappelle ni le visage ni la voix, mais dont je me rappelle qu'il courait et qu'il m'a dit de ne pas regarder derrière.

Vaugrin était de Ghar. Dix-neuf ans dans la même halle, à trois pas de moi.

Il ne me l'a jamais dit. Je ne le lui ai jamais demandé.

C'est ce qu'on nous a appris à faire, nous autres : ne pas demander, pour ne pas entendre.

J'ai mis la plaque dans ma poche intérieure. Elle y est restée tout le voyage.

Et quand Ysée Marrec m'a demandé, bien plus tard, au milieu du feu, pourquoi j'avais accepté de traverser, c'est cette plaque que j'ai sortie, et pas un mot.
