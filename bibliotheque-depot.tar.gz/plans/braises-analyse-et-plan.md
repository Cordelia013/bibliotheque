# La Saison des Braises — Analyse, références et plan de développement révisé

## Série : *Les Trois Cents Lieues* — tome 1 sur 3

**Structure de la série** :
- **Tome 1 — La Saison des Braises** (50 chapitres) : Valdren, la route, la traversée, le Nord, le retour. Arc fermé : le contrat de Cael, Halden Serrande, et la carte rapportée. Arc ouvert : ce qu'Ysée a laissé délibérément en blanc, et les gens qui vivent dedans.
- **Tome 2 — Le Blanc** *(titre de travail)* : la carte est publiée, amputée. Les deux princes qui l'avaient commandée s'en aperçoivent. Une seconde expédition part, sans Ysée et sans Cael, et ils doivent décider s'ils la devancent. Le Nord, cette fois, est vu de l'intérieur : la communauté de Braises libres, ses propres règles, et le fait qu'elle n'a jamais demandé à être protégée.
- **Tome 3 — titre à venir** : le Sud apprend ce qu'il a fait pendant la Guerre des Fours. Les neuf cartes d'Ysée, celles qu'elle a copiées à seize ans, reviennent — non plus comme une honte privée, mais comme une preuve.

**Ce que cela change dans le tome 1** : l'acte V ne doit pas résoudre la question morale. Ysée choisit ce qu'elle laisse en blanc ; le livre se termine sur ce choix, pas sur ses conséquences. Le dernier chapitre, sur la Ligne dans l'autre sens, garde un fil : quelqu'un les suit, ou quelqu'un les attend.

**Diagnostic de départ** : les cinq chapitres écrits couvrent, en 3 000 mots, ce que le genre étale habituellement sur 25 à 30 % du livre. Le lecteur arrive à la Ligne des Cendres sans connaître la Guilde, sans savoir pourquoi Ysée n'a pas de famille, sans avoir vu ce qu'est la vie d'un Braise sous contrat, et sans comprendre l'enjeu politique de la carte. Le désir fonctionne parce que les scènes sont justes ; ce qui manque, c'est le *sol* sous le désir.

---

## 1. Ce que dit le genre (recherche)

**Le principe fondateur.** Dans un slow burn, l'attraction est établie tôt, mais ce sont les obstacles, la retenue et les occasions manquées qui maintiennent les personnages séparés jusqu'à ce que la récompense soit méritée. Le slow burn est une promesse structurelle : le lecteur accepte d'attendre, à condition que l'attente *fasse* quelque chose.

**Ce qui fait échouer un slow burn.** Le lecteur doit comprendre tôt ce qui sépare les personnages, sinon le slow burn semble seulement… lent. Et en enemies-to-lovers, si la haine est superficielle, tout s'effondre : les meilleurs conflits viennent de croyances qui s'opposent, enracinées dans une trahison, une rivalité ou une blessure ancienne. Les deux personnages doivent avoir raison de leur point de vue.

**La règle la plus utile pour nous.** Dans un romantasy long, les beats de la relation sont espacés de plusieurs milliers de mots, et cet espace ne se remplit pas avec davantage de désir ; il se remplit avec *l'autre intrigue* — la guerre, la cour, le système de magie — et c'est cette intrigue qui force le couple dans de nouvelles configurations d'accès et de risque. En pratique, chaque beat romantique devrait être déclenché par un événement extérieur, jamais par un personnage qui décide qu'il est temps de ressentir autre chose.

**Répartition classique.** Acte 1 (25 %) : installer la tension romantique *et* le conflit fantasy ; Acte 2A (25 %) : approfondir le lien et faire monter les enjeux. Les tropes ne sont que des cadres : le problème survient quand on les utilise tels quels et que toute la personnalité de la relation se résume au trope, ou qu'on en empile cinq à la suite.

---

## 2. Comment les livres de référence construisent leur ouverture

Analyse de structure et de dynamique uniquement — pas de résumé d'intrigue.

### Fourth Wing (Rebecca Yarros, 2023)
- **Le temps de l'ouverture** : les sept premiers chapitres constituent une partie à part entière, où l'héroïne est projetée dans un monde qui veut sa mort. Rien n'est encore romantique. Tout est *institution* : règles, hiérarchie, mortalité.
- **Le désir arrive par la menace** : dès les premiers chapitres, l'attraction pour l'antagoniste est mêlée à un avertissement explicite d'un proche — il est dangereux, il faut l'éviter. Le lecteur reçoit le désir et l'interdit dans la même scène.
- **Dispositif de contexte** : chaque chapitre s'ouvre sur un extrait de document interne au monde, et des flashbacks du père mort installent des informations qui ne s'expliquent qu'au climax.
- **Ce qui accélère le lien** : les scénarios d'entraînement mortels resserrent l'émotion — le danger fait le travail que le temps ferait ailleurs.
- **Point faible reconnu** : le cadre de l'académie est décrit avec précision, mais le monde extérieur reste flou, ce qui laisse le lecteur sur sa faim.

### A Court of Thorns and Roses (Sarah J. Maas, 2015)
- **Pile de tropes assumée** : le lien surnaturel attire, le slow burn cadence, l'interdit alimente l'obstacle — c'est décrit comme « le réglage par défaut du romantasy ».
- **Dynamique** : monde politique, lecteurs sensibles aux intrigues de cour et à la lenteur assumée de la romance.
- **Leçon** : l'héroïne arrive dans le monde magique *après* qu'on a vu sa vie d'avant (la pauvreté, la famille, la chasse). Le contraste fait exister le monde nouveau.

### Ce que je connais par ailleurs du genre (non issu de la recherche, à prendre comme mon analyse)
- **Serpent & Dove (Shelby Mahurin)** : mariage forcé entre une sorcière et un chasseur de sorcières. La structure donne *deux* mondes complets avant la rencontre — on voit chaque personnage chez lui, avec ses règles, avant de les enfermer ensemble. La proximité forcée n'a de sens que parce qu'on a mesuré la distance idéologique.
- **From Blood and Ash (Jennifer L. Armentrout)** : l'héroïne a une fonction sociale sacrée qui la prive de vie propre ; le garde du corps est l'obstacle *et* le seul accès à l'extérieur. Le premier quart du livre est consacré à la cage — on comprend le poids de chaque transgression parce qu'on a vu le prix.
- **Constante des trois** : dans chaque cas, le voyage ou l'enfermement commence après 20 à 30 % du livre. Le lecteur a vu la vie d'avant, la contrainte institutionnelle, et au moins une scène où le personnage principal a *choisi* quelque chose. Le départ n'est pas une ouverture, c'est un point de non-retour.

---

## 3. Ce que cela révèle sur notre manuscrit

| Élément du genre | Dans les cinq chapitres actuels | Ce qui manque |
|---|---|---|
| Vie d'avant de l'héroïne | Une phrase : « la seule à ne pas avoir de famille » | Pourquoi. Ce que ça lui a coûté à la Guilde. Ce qu'elle y a construit malgré tout. |
| Institution et ses règles | La règle « on ne dessine que ce qu'on a vu » | Le fonctionnement de la Guilde, la hiérarchie, ce que la carte du Nord vaut politiquement, qui la veut et pourquoi maintenant. |
| Vie d'avant du héros | Trois mots : « signé », « les Fours », « contrat » | Ce qu'est un contrat de Braise au quotidien. À qui il appartenait. Ce qu'il a fait pendant la Guerre des Fours. Ce que « levée de contrat » signifie pour lui. |
| Conflit de croyances (enemies-to-lovers) | Frottement de caractères | Une vraie opposition : ce qu'Ysée pense des Braises avant d'en rencontrer un ; ce que Cael pense de la Guilde qui a cartographié les zones de guerre. |
| Un choix avant le départ | Aucun : Ysée est convoquée et part | Au moins une scène où elle pourrait refuser et ne refuse pas, pour une raison à elle. |
| Beat romantique déclenché par l'intrigue | Le lit unique (auberge), la traversée | Fonctionnent — mais arrivent avant que l'intrigue extérieure existe. |
| Danger extérieur qui resserre le lien | Aucun avant la Ligne | Un antagoniste humain. Quelqu'un qui ne veut pas que cette carte existe. |

---

## 4. Le monde, développé

### La Guilde des Cartographes
- Siège à **Valdren**, ville-port du Sud. Trois ordres : les **Relevés** (terrain), les **Copistes** (atelier), les **Doyens** (pouvoir). Une cartographe de terrain sans famille ne monte jamais au-dessus des Relevés — pas par règle écrite, par usage.
- La Guilde vend ses cartes aux princes. Une carte du Nord au-delà de la Ligne vaut une fortune : personne ne sait ce qu'il reste là-bas — des villes, des mines, des survivants.
- Le Doyen **Aldric Vael** a fait sa carrière sur les cartes de guerre des Fours. Il a cartographié pour l'armée les zones où les Braises étaient concentrés. Il sait exactement ce que Cael pense de lui.

### La Guerre des Fours (il y a vingt-deux ans)
- Les Fours étaient des forges-cités du Nord où le feu de la terre était domestiqué. Une guerre entre le Sud et le Nord pour leur contrôle a mal tourné : les Fours ont été rompus, et la terre a commencé à brûler. C'est la Ligne des Cendres.
- Les Braises sont les enfants nés dans les Fours pendant ou juste après la rupture. Le feu est en eux. Il y en a quelques centaines. Le Sud les a « accueillis » sous contrat — logés, nourris, et tenus. Un Braise sans contrat est un Braise hors-la-loi.
- Cael avait cinq ans. Il ne se souvient de rien avant le feu. Il se souvient de tout après.

### Le contrat de Cael
- Il appartient à la maison **Serrande**, une famille de marchands de sel de Valdren. Il a servi dix-neuf ans comme chauffeur de fours industriels — un Braise fait fondre le sel gemme sans combustible. C'est un travail qui use le corps de l'intérieur.
- La « levée de contrat » promise par le Doyen n'est pas un affranchissement : c'est un **transfert**. Le Doyen a racheté son contrat aux Serrande. Cael ne l'apprendra qu'au chapitre 9. Ysée ne l'apprendra qu'à la Ligne.

### Ysée Marrec
- Née à Valdren, orpheline à sept ans — ses parents étaient copistes, morts dans l'incendie de l'atelier Est. Recueillie par la Guilde comme « pupille », ce qui signifie : formée gratuitement, sans jamais pouvoir refuser une mission.
- Elle a vingt-quatre ans. Elle est la meilleure des Relevés de sa promotion et la seule sans protecteur. Sa règle personnelle : elle ne dessine que ce qu'elle a vu, et elle *note* tout le reste dans un carnet à part, qu'elle appelle « le blanc ».
- Ce qu'elle pense des Braises avant Cael : ce qu'on lui a appris. Qu'ils sont dangereux, instables, et que la Guilde a bien fait de cartographier leurs zones pendant la guerre. Elle a copié ces cartes à seize ans. Elle en est fière. Elle va cesser de l'être.

### L'antagoniste humain : Halden Serrande
- Fils aîné de la maison Serrande, trente-deux ans. Il a perdu le contrat de Cael au profit du Doyen et il le vit comme un vol.
- Il ne veut pas que la carte du Nord existe : la maison Serrande tient le monopole du sel du Sud ; des mines de sel retrouvées au-delà de la Ligne le ruineraient.
- Il fera suivre le duo. Il n'est pas un monstre. Il est un homme qui défend un monopole, et c'est pire.

---

## 5. Structure révisée (50 chapitres)

Les cinq chapitres actuels ne sont pas perdus : ils deviennent les chapitres **13, 15, 18, 22 et 24**, retravaillés pour intégrer ce qui les précède.

### Acte I — Valdren (chapitres 1 à 12) · *avant le départ*
**Objectif** : le lecteur connaît la Guilde, la Guerre des Fours, la condition des Braises, et voit Ysée choisir.

- Ch. 1 (Ysée) : L'atelier des Relevés à l'aube. Ysée termine une carte côtière que signera un autre. On voit son métier, sa place, sa règle. Une convocation arrive.
- Ch. 2 (Ysée) : Le Doyen Vael. La carte du Nord, les trois cents lieues de blanc, et pourquoi maintenant : deux princes ont commandé la même carte. Elle est « la seule sans famille pour s'opposer ». Elle demande vingt-quatre heures.
- Ch. 3 (Cael) : Le four à sel des Serrande. Dix-neuf ans de chaleur. Ce qu'un Braise fait de ses mains, et ce que ça lui coûte. Halden Serrande lui annonce que son contrat est « levé ». Cael ne le croit pas.
- Ch. 4 (Ysée) : La nuit des vingt-quatre heures. Elle sort les cartes de guerre des Fours qu'elle a copiées à seize ans. Elle regarde les zones hachurées où l'armée a marqué les concentrations de Braises. Elle réalise ce qu'elle a dessiné.
- Ch. 5 (Ysée) : Elle accepte. Pas parce qu'on l'y oblige — parce qu'elle veut dessiner le blanc, et parce qu'elle veut savoir ce qu'il y a derrière les hachures.
- Ch. 6 (Cael) : Le transfert. Il découvre que « levée » veut dire « rachetée par le Doyen Vael » — l'homme qui a tracé les cartes de guerre. Il signe quand même. Il a une raison que le lecteur ne connaît pas encore.
- Ch. 7 (Ysée) : La cour des écuries. Première rencontre — la scène actuelle du chapitre 1, mais Ysée arrive avec ce qu'elle sait des Braises, et Cael avec ce qu'il sait de la Guilde. La froideur a désormais un fond.
- Ch. 8 (Cael) : Il retire deux livres sur trois. Il voit son carnet, « le blanc ». Il comprend qu'elle n'est pas ce qu'il croyait, et il décide de ne pas le montrer.
- Ch. 9 (Ysée) : Halden Serrande vient la trouver. Il lui propose de l'argent pour que la carte reste blanche. Elle refuse. Il ne menace pas : il sourit.
- Ch. 10 (Cael) : Veille du départ. Il retourne au four à sel une dernière fois, la nuit. Ce qu'il y laisse. Ce qu'il emporte.
- Ch. 11 (Ysée) : Départ à l'aube. Le Doyen ne vient pas. Halden est sur les remparts.
- Ch. 12 (Cael) : **Cliffhanger d'acte** — première nuit de route. Il fait le feu avec ses mains. Elle ne regarde pas. Et il comprend qu'elle a détourné les yeux *exprès*.

### Acte II — La route (chapitres 13 à 24) · *douze jours*
**Objectif** : la proximité s'installe par l'intrigue, pas par décision. Halden suit.

- Ch. 13 (Ysée) : Quatre jours de selle. La chute. « Ne dites rien. » *(actuel ch. 2, POV inversé)*
- Ch. 14 (Cael) : Il l'a rattrapée. Il a lâché la manche trop tôt. Il sait qu'elle a remarqué.
- Ch. 15 (Cael) : Ce que la Ligne reconnaît. Le secret du Doyen. *(actuel ch. 2, cœur)*
- Ch. 16 (Ysée) : Un village de la frontière. Les Braises y sont interdits d'auberge. Elle exige qu'on le loge ou elle dort dehors. Première fois qu'elle prend son parti en public.
- Ch. 17 (Cael) : Il ne la remercie pas. Il ne sait pas comment. Il fait autre chose : il lui apprend à seller.
- Ch. 18 (Ysée) : L'auberge du Gué. Une chambre. *(actuel ch. 3)*
- Ch. 19 (Cael) : Le matelas qui cède. Il sait qu'elle sait.
- Ch. 20 (Ysée) : Un cavalier derrière eux, depuis trois jours. Elle le voit avant lui.
- Ch. 21 (Cael) : L'embuscade des hommes de Serrande. Cael se bat avec le feu pour la première fois devant elle. Elle voit ce qu'il est.
- Ch. 22 (Ysée) : Elle le dessine, cette nuit-là. Pas la carte. Lui. *(actuel ch. 2, fin — « je vous dessine »)*
- Ch. 23 (Cael) : La veille. Il lui dit ce que la Ligne exige. *(actuel ch. 4)*
- Ch. 24 (Ysée) : **Cliffhanger d'acte** — « Je m'entraîne à la distance. » Elle s'endort contre son bras. Au loin, les feux des hommes de Serrande.

### Acte III — La Ligne (chapitres 25 à 34) · *trois jours*
- Ch. 25 à 27 : La traversée. *(actuel ch. 5, développé sur trois chapitres : jour un, deux, trois)* La chaleur, la distance, la peur de Cael. Assez près.
- Ch. 28 (Cael) : Il ne tient pas. La nuit du deuxième jour. Ce qui se passe entre eux se passe hors champ ; ce qui se dit se dit.
- Ch. 29 (Ysée) : Le matin. Elle ne regrette rien. Il croit qu'elle devrait.
- Ch. 30 (Ysée) : L'autre côté. Ce qu'il y a derrière les hachures : des ruines, et des gens.
- Ch. 31 (Cael) : Le Nord se souvient de lui. Ou de quelqu'un qui lui ressemble.
- Ch. 32 (Ysée) : Elle commence la carte. La première ligne dans le blanc.
- Ch. 33 (Cael) : Halden a traversé. Avec un Braise à lui.
- Ch. 34 : **Cliffhanger d'acte** — Cael révèle pourquoi il a signé : il y a quelqu'un dans le Nord qu'il cherche depuis vingt-deux ans.

### Acte IV — Le Nord (chapitres 35 à 44)
- La cité des Fours, ce qu'il en reste. Une communauté de Braises libres. La tentation pour Cael de rester. Le choix d'Ysée : la carte peut détruire cet endroit si elle la rapporte. Halden. La confrontation. Une rupture entre eux qui vient de leurs croyances, pas d'un malentendu.

### Acte V — Le retour (chapitres 45 à 50)
- Ce qu'Ysée rapporte à Valdren. Ce qu'elle laisse en blanc, volontairement, pour la première fois de sa vie. La levée de contrat, la vraie. Le dernier chapitre sur la Ligne, à deux, dans l'autre sens.

---

## 6. Règles de rédaction ajoutées

- **Chaque chapitre de l'acte I doit contenir un élément de monde et un élément de personnage.** Pas de chapitre de pur contexte, pas de chapitre de pure émotion.
- **Le désir ne monte jamais sans que quelque chose d'extérieur l'ait déplacé** : une auberge, une embuscade, une règle, un cavalier au loin.
- **Ysée choisit avant de subir.** Le chapitre 5 est le pivot : elle accepte pour ses raisons.
- **Cael a une raison secrète de signer, connue du lecteur au chapitre 34 seulement.** Les indices sont plantés aux chapitres 6, 10 et 31.
- **Halden Serrande a raison de son point de vue**, et on le laisse l'expliquer une fois, sans le ridiculiser.
- **Le fondu au noir est une règle du livre**, pas une pudeur : ce qui se passe entre eux est écrit par ce qu'ils se disent après.
